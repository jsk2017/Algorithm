DES
===

DES algorithm implementation using C